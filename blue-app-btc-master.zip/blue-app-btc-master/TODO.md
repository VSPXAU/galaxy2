# BTC Application TODOs 

  - [X] Sign message support 
  - [X] Altcoins fixes (signing message format, prompts)  
  - [ ] Support an arbitrary number of TX outputs   
  - [ ] Support device / PIN locking in next firmware update    

