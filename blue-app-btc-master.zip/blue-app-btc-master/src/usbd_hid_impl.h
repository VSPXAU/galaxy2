#ifndef USBD_HID_IMPL_H
#define USBD_HID_IMPL_H

#define HID_EPIN_ADDR                 0x82
#define HID_EPIN_SIZE                 0x40

#define HID_EPOUT_ADDR                0x02
#define HID_EPOUT_SIZE                0x40

#endif // USBD_HID_IMPL_H

