#!/bin/bash
node node_modules/browserify/bin/cmd.js ledger-btc.js -s LedgerBtc -o bundle.js
