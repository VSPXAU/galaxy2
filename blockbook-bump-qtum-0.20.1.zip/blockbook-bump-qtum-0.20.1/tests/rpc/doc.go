// Package rpc implements integration tests of blockchain RPC layer
package rpc
