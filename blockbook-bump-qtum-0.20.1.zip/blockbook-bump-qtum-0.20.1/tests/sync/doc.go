// Package sync implements integration tests of synchronization code
package sync
