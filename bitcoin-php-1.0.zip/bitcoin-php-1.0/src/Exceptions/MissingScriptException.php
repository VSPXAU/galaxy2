<?php

namespace BitWasp\Bitcoin\Exceptions;

class MissingScriptException extends ScriptQualificationError
{

}
