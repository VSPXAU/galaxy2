<?php

namespace BitWasp\Bitcoin\Exceptions;

class Base58InvalidCharacter extends \Exception
{

}
