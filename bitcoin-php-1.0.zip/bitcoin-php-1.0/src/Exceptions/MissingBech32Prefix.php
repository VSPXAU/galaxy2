<?php


namespace BitWasp\Bitcoin\Exceptions;

class MissingBech32Prefix extends \Exception
{

}
