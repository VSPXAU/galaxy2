<?php

declare(strict_types=1);

namespace BitWasp\Bitcoin\Exceptions;

class DisallowedScriptDataFactoryException extends \Exception
{

}
