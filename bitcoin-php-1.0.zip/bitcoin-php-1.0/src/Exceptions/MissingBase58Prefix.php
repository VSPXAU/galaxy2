<?php

namespace BitWasp\Bitcoin\Exceptions;

class MissingBase58Prefix extends \Exception
{

}
