<?php

namespace BitWasp\Bitcoin\Exceptions;

class P2shScriptException extends \Exception
{

}
