<?php

namespace BitWasp\Bitcoin\Exceptions;

class MissingBip32Prefix extends \Exception
{

}
