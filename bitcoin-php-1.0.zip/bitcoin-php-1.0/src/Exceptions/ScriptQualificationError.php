<?php

namespace BitWasp\Bitcoin\Exceptions;

class ScriptQualificationError extends \RuntimeException
{

}
